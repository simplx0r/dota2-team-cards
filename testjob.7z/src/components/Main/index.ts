export { default } from "./Main";
