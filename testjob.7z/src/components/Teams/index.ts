export { default } from "./Teams";
